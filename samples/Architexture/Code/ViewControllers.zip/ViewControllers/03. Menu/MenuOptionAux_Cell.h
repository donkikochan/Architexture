//
//  MenuOptionAux_Cell.h
//  Architexture
//
//  Created by Enric Vergara Carreras on 28/09/13.
//
//


//---Imports:---
#import <UIKit/UIKit.h>
//--------------

@interface MenuOptionAux_Cell : UITableViewCell
{ }

//---IBOutlets:
@property (strong, nonatomic) IBOutlet UIButton     *m_Button_Facebook;
@property (strong, nonatomic) IBOutlet UIButton     *m_Button_Twitter;
@property (strong, nonatomic) IBOutlet UIButton     *m_Button_Like;

//---IBActions:
//...

//---Functions:
//...

@end