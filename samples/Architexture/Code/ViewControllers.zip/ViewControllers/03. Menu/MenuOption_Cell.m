//
//  MenuOption_Cell.m
//  Architexture
//
//  Created by Enric Vergara Carreras on 10/09/13.
//
//

#import "MenuOption_Cell.h"

@implementation MenuOption_Cell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
