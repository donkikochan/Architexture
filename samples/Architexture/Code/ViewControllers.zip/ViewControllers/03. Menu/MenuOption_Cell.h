//
//  MenuOption_Cell.h
//  Architexture
//
//  Created by Enric Vergara Carreras on 10/09/13.
//
//

#import <UIKit/UIKit.h>

@interface MenuOption_Cell : UITableViewCell
{
    
}

@property (strong, nonatomic) IBOutlet UIButton     *m_Button_Option;
@property (strong, nonatomic) IBOutlet UILabel      *m_Label_Option;
@property (strong, nonatomic) IBOutlet UIImageView  *m_Image_Option;
@end
