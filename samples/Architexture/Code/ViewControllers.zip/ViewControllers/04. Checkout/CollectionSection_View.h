//
//  CollectionSection_View.h
//  Architexture
//
//  Created by Enric Vergara Carreras on 10/09/13.
//
//

#import <UIKit/UIKit.h>

@interface CollectionSection_View : UIView
{}

- (id)initWithCollectionName:(NSString*) _collectionName;
@end
