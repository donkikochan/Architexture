//
//  LoadingCollection_VC.h
//  Architexture
//
//  Created by Enric Vergara Carreras on 20/09/13.
//
//

#import <UIKit/UIKit.h>

@interface LoadingCollection_VC : UIViewController
{
    
}

//---IBOutlets:
@property (weak, nonatomic) IBOutlet UILabel *m_Label_Loading;

//---IBActions:

//---Functions:
//...
@end
