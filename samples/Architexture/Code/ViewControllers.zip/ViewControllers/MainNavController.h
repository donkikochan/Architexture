//
//  MainNavigationController.h
//  achitexture
//
//  Created by DonKikochan on 10/07/13.
//  Copyright (c) 2013 architexture. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainNavController : UINavigationController

@end
